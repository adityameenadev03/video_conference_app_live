function Message({message}) {

  return (
    <div className='message'>
      <span>Sender name</span>
      <p>Message</p>
    </div>
  )
}

export default Message